#!/system/bin/sh
MODDIR=${0%/*}
LOG="$MODDIR/logs/kill_app.log"
mkdir -p "$MODDIR/logs";touch "$LOG";chmod 0644 "$LOG"
nohup "$MODDIR/scripts/kill_app.sh" monitor >/dev/null 2>&1 &
