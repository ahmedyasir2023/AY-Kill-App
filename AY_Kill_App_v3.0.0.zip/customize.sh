SKIPUNZIP=0
ui_print "- Installing AY Kill App v3.0.0"
ui_print "- Developed by Eng. Ahmed Yasir"
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
set_perm "$MODPATH/action.sh" 0 0 0755
set_perm "$MODPATH/scripts/kill_app.sh" 0 0 0755
ui_print "- Installation complete"
ui_print "- Reboot to activate instant exit monitoring"
