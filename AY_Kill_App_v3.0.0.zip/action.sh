#!/system/bin/sh
MODDIR=${0%/*}
"$MODDIR/scripts/kill_app.sh" kill-all
