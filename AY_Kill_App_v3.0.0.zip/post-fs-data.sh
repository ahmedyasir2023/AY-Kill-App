#!/system/bin/sh
MODDIR=${0%/*}
mkdir -p "$MODDIR/logs"
[ -f "$MODDIR/config.json" ]||cp "$MODDIR/config.default.json" "$MODDIR/config.json"
chmod 0644 "$MODDIR/config.json" 2>/dev/null
