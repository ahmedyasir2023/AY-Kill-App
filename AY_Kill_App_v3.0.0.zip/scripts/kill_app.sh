#!/system/bin/sh
MODDIR=${0%/*}
CONFIG="$MODDIR/config.json"
LOG="$MODDIR/logs/kill_app.log"
STATE="$MODDIR/logs/foreground.state"
mkdir -p "$MODDIR/logs"
touch "$LOG" "$STATE"

log(){echo "$(date '+%F %T') $1">>"$LOG";}
toast(){cmd notification post -S bigtext -t "AY Kill App" "ay_kill_app" "$1">/dev/null 2>&1;}
json_val(){sed -n "s/.*\"$1\"[[:space:]]*:[[:space:]]*\([0-9]\+\).*/\1/p" "$CONFIG"|head -n 1;}
bool(){grep -q "\"$1\"[[:space:]]*:[[:space:]]*true" "$CONFIG" 2>/dev/null;}
excluded(){grep -q "\"$1\"" "$CONFIG" 2>/dev/null;}
protected(){case "$1" in com.android.systemui|com.android.phone|com.android.settings|com.android.launcher|com.android.launcher3|com.google.android.gms|com.android.providers.telephony|com.android.providers.contacts|com.android.bluetooth|com.android.se|com.android.stk|com.android.inputmethod*|com.android.keychain|com.android.networkstack*|com.android.server.telecom|com.android.shell|com.android.vending|com.android.documentsui|com.android.packageinstaller|com.android.permissioncontroller|com.android.incallui|com.android.systemui*)return 0;;esac;return 1;}
current_app(){pkg=$(dumpsys activity activities 2>/dev/null|sed -n 's/.*topResumedActivity=.*u0[[:space:]]*\([^ /}\n]*\).*/\1/p'|head -n 1);[ -z "$pkg" ]&&pkg=$(dumpsys window displays 2>/dev/null|sed -n 's/.*mCurrentFocus=.*\(\(\w\+\.[\w\.]\+\)\).*/\1/p'|head -n 1);[ -z "$pkg" ]&&pkg=$(dumpsys window 2>/dev/null|sed -n 's/.*mCurrentFocus=.*\(\(\w\+\.[\w\.]\+\)\).*/\1/p'|head -n 1);echo "$pkg";}
force_stop(){pkg="$1";protected "$pkg"&&return 1;am force-stop "$pkg">/dev/null 2>&1&&{log "OK $pkg";return 0;};log "FAIL $pkg";return 1;}
monitor(){bool '"monitor_enabled"'||return 0;delay=$(json_val 'exit_delay_ms');[ -z "$delay" ]&&delay=300;while true;do current=$(current_app);[ -z "$current" ]&&{sleep 1;continue;};previous=$(cat "$STATE" 2>/dev/null);if [ -n "$previous" ]&&[ "$previous"!="$current" ]&&!protected "$previous"&&!excluded "$previous";then sleep "$delay" 2>/dev/null||sleep 1;now=$(current_app);if [ "$now"!="$previous" ];then force_stop "$previous"&&bool '"show_toast"'&&toast "تم إيقاف تطبيق إجباريًا: $previous";fi;fi;echo "$current">"$STATE";sleep 1;done;}
kill_all(){count=0;for pkg in $(pm list packages -3 2>/dev/null|sed 's/^package://');do [ -z "$pkg" ]&&continue;protected "$pkg"&&continue;excluded "$pkg"&&continue;force_stop "$pkg"&&count=$((count+1));done;log "KILL_ALL count=$count";bool '"show_toast"'&&toast "تم إغلاق $count تطبيق إجباريًا";echo "$count";}
case "$1" in monitor)monitor;;kill-all)kill_all;;*)monitor;;esac
